 <?php require_once ('headnav.php'); 
?>
<div class="container">

 <?php    check_message(); ?>
  <div class="col-xs-12 col-sm-9">
   
        <div class="">
          <div class="panel panel-default">
        
              <div class="panel-body">  
                <div class="col-xs-12 col-sm-12">

								<fieldset>
								<fieldset>
										<legend><h2 class="text-left">About</h2></legend>
									
										 

									</fieldset>
									<hr/>
									<fieldset>

										<legend><h2 class="text-left">Company Mission</h2>To keep customers satisfied by serving them quality and freshly baked goods at reasonable prices.</legend>
										
										
									</fieldset>	

									<fieldset>
									
										<legend><h2 class="text-left">Company Vision</h2>Katerina envisions to maintain a safe, healthy and vibrant workplace for its employees in order to serve our customers best.</legend>
								
									</fieldset>
									
									 </fieldset>

								</div>
							</div>
						</div>		
				
					
				</div>
		
		</div>
	<?php require_once 'sidebar.php';?>
</div>
