 <?php require_once ('headnav.php'); 
?>

	<div class="col-md-9 col-sm-9">
		
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
							
 
								<legend><h3 class="text-left">Map</h3></legend>

									<iframe src="https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d238.86316051731683!2d121.5474141!3d16.6863602!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sph!4v1458537001255" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
				
							</div>
						</div>		
				
					
				</div>
		
		</div>
	<?php require_once 'sidebar.php';?>

