<!DOCTYPE HTML>
<html>
<head><h1 align="center">Welcome <?php echo $_SESSION['TYPE'] ?>.</h1> </head><br/>
<body>
    <p align="center"><img src="<?php echo web_root; ?>images/adminpic.jpg"></p>
</body>
</html>
