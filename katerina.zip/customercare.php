 <?php require_once ('headnav.php'); 
?>
<div class="container">
	<div class="col-lg-9">
<h3>How can I order in Katerina website?</h3><br/>
<ol>
	<li>Choose the product you want and proceed to checkout</li>
	<li>At Login step, enter your username and password</li>
	<li>Enter your delivery information and choose your payment method</li>
	<li>Place your order</li>
	<li>Wait for notification of confirmation in your profile.</li>
</ol>
<h3>Removing an item in the cart</h3>
<ul><h4>To remove an item in the cart:</h4>
	<li>Click on the cart icon on top beside the customer care of Katerina page.

 <li>In action, click “Remove”.</li>
<li>Your cart will be updated and the removed item will no longer be in there.</li>
</ul>
 
 </ol>
<h3>Confirmation of order</h3>
<ul>
	
	<li>An order confirmation with an order summary will be sent to your profile right after placed order.</li>
 
<li>This is to notify that the order has been confirmed. 
</li>
</ul>
 

	</div>

	<?php require_once 'sidebar.php';?>
</div>
